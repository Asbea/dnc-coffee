const card = document.querySelectorAll(".card")
const hidden = document.querySelectorAll(".botaoCompra")


hidden.forEach(value => value.style.visibility = "hidden")

card.forEach(value => {
    value.addEventListener("mouseover", ()=>{
        let botaoCompra = value.querySelector(".botaoCompra")
        botaoCompra.style.visibility = "visible"
    })
    value.addEventListener("mouseout", ()=>{
        let botaoCompra = value.querySelector(".botaoCompra")
        botaoCompra.style.visibility = "hidden"
    })
})
